import xlsxwriter as xlsx
import random



wb = xlsx.Workbook('wind-dataset.xlsx')
sheet = wb.add_worksheet()

isEmpty = True 
row = 0
col = 0
sensitivity = 0.25

column_content = ['X-ac', 'X-bc', 'z', 'z0', 'R-r', 'C-t', 'VD-ac', 'VD-bc']
data = [500, 200, 60, 0.3, 20, 0.88, 0.0208, 0.1116]

for item in column_content:
    sheet.write(row, col, item)
    col += 1

while row <= 50:
    col = 0
    row += 1

    for item in data:
        ul = random.random() * sensitivity
        ll = random.random() * -sensitivity
        sheet.write(row, col, item * (1 + ul + ll)) 
        col+=1

wb.close()